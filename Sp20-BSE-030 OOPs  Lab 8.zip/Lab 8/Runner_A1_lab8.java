/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg8;
import java.util.Scanner;

public class Runner_A1_lab8 {
    public static void main(String[]args){
        
        String s;
        System.out.println("enter the title of the cassete");
        Scanner input = new Scanner(System.in);
        s  = input.next();
        int a;
        System.out.println("Enter the time of plying in minutes");
        a = input.nextInt();
        int b;
        System.out.println("Enter the price of the cassete");
        b = input.nextInt();
        Tape T = new Tape(a, s, b);
        T.Display();
        String t;
        System.out.println("enter the name of the book");
        t  = input.next();
        int x;
        System.out.println("Enter the total pages of the book");
        x = input.nextInt();
        int y;
        System.out.println("Enter the price of the book");
        y = input.nextInt();
        Book B = new Book(x, t, y);
        B.Display();
        
    }
    
}
