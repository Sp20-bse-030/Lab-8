/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg8;

public class Person {              //creating a class person
    protected String name;
    protected String address;
    protected String email;
    protected String phone;

    public Person(String name,String address, String email, String phone) {      // an argumented constructor
        this.name = name;
        this.address = address;
        this.email = email;
        this.phone = phone;
    }
    public void Display(){            // a Display method to display all data feilds
        System.out.println("Name is "+ name + ", he is from " + address + ", his email address is " + email+ " and his phone number is " + phone);
    }
   
}
// Perosn class ends
class Student extends Person{            // Creating a new Class Student inherit a Person class
    private String status;

    public Student( String status,String a, String b, String c, String d) {
        super(a,b,c,d);                  // accessing the constructor of parent class using super keyword
        this.status = status;
    }
    public void Display(){               // Display method to Display all Data feilds
        super.Display();
        System.out.println("Status is" + status);
    }
}
// Student class ends
class Date{                             // creating a new class Date
    private int day;
    private int month;
    private int year;

    public Date(int day, int month, int year) {         // creates an argumented constructor
        this.day = day;
        this.month = month;
        this.year = year;
        
    }
    public void Display(){
        if(day > 31){
            System.out.println("you have entered a wrong date, date < 31");
        }
        else if(month>12){
            System.out.println("you have entered a wrong month, month < 12");
        }
        else
        System.out.println("Date of hired is " + day+"/" +month+"/" + year);
    } 
}
// Date class ends 
class Employee extends Person{            // a new class Employee inherits a Person class
    protected  int salary;
    private Date hireddate;

    public Employee(int salary, Date hireddate,String a, String b, String c, String d) { // an argumented constructor
        super(a,b,c,d);                    // accessing the contructor of parent class
        this.salary = salary;
        this.hireddate = hireddate;
    }
    public void Display(){
        super.Display();
        hireddate.Display();
        System.out.println( "Salary is " + salary);
    }
    
    
}
// Employee class ends
class Faculty extends Employee{               // a new class Faculty inherits an Employee class
    int hours;
    String rank;

    public Faculty(int hours, String rank, int salary, Date hireddate,String a, String b, String c, String d) {         // an argumented constructor
        super(salary,hireddate,a,b,c,d);
        this.hours = hours;
        this.rank = rank;
    }
    public void Display(){
        super.Display();
        System.out.println("Having rank " + rank + " and his working hours are  " + hours + " hours");
    }
}
// Faculity class ends
class Staff extends Employee{            // a new class Staff inherits an Employee class
    String title;

    public Staff(String title,int salary, Date hireddate,String a, String b, String c, String d) {
        super(salary, hireddate, a ,b, c, d);               // accessing the constructor of parent class using super keyword
        this.title = title;
    }
    public void Display(){
        super.Display();                   // invoking the Display method of parent class Employee
        System.out.println("staff member has a title "+ title);
    }
}
//Staff class ends

