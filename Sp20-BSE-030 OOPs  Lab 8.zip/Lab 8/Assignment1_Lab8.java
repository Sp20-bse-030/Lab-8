/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg8;


public class Publication {                  // craetes a calss Publication
    protected String title;
    protected int price;

    public Publication(String title, int price) {      // an argumented constructor 
        this.title = title;
        this.price = price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getPrice() {
        return price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public void Display(){
        System.out.println("Title is " + title + " and price is " + price +" Rupees");
    }
}
// Punlication class ends
class Book extends Publication{                  // creates a new class Book inherits Publication class 
    private int count;

    public Book(int count,String t, int p) {     // an argumented construtor
        super(t,p);
        this.count = count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }
    public void Display(){
        super.Display();
        System.out.println("Total pages are "  + count);
    }
            
}
//Book class ends
class Tape extends Publication{                         // creates a new class Tape inherits Publication class 
    private int time;

    public Tape(int time,String t, int p) {             // an argumented construtor
        super(t,p);
        this.time = time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getTime() {
        return time;
    }
    public void Display(){
        super.Display();
        System.out.println("Total playing time for the cassete is  " + time +" minutes");
    }
    
}
// Tape class ends
