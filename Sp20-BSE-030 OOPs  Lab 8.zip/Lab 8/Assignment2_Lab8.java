/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg8;

public class Computer {                  // Creates a computer class 
    protected int wordsize;
    protected int memorysize;
    protected int storagesize;
    protected int speed;

    public Computer() {                 // a non-argumented constructor
        this.wordsize = 20;
        this.memorysize = 500;
        this.storagesize = 450;
        this.speed = 250;
    }

    public void setWordsize(int worsize) {
        this.wordsize = worsize;
    }

    public void setMemorysize(int memorysize) {
        this.memorysize = memorysize;
    }

    public void setStoragesize(int storagesize) {
        this.storagesize = storagesize;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getWordsize() {
        return wordsize;
    }

    public long getMemorysize() {
        return memorysize;
    }

    public long getStoragesize() {
        return storagesize;
    }

    public long getSpeed() {
        return speed;
    }
    public void Display(){
        System.out.println("Word size is " +wordsize + " bits, memorysize is  " + memorysize + " megabytes, storagesize is " +storagesize + " megabytes and speed is " + speed + " megahertz"  );
    }
    
}
// Computer class ends
class Laptop extends Computer{                     // Creates a Laptop class inherits the Computer classs
    int length,width, heigth, weigth;

    public Laptop() {                              // a non-argumented constructor
        super();
        length = 4;
        width = 5;
        heigth = 6;
        weigth = 3; 
    }

    public void setLength(int length) {
        this.length = length;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeigth(int heigth) {
        this.heigth = heigth;
    }

    public void setWeigth(int weigth) {
        this.weigth = weigth;
    }

    public int getLength() {
        return length;
    }

    public int getWidth() {
        return width;
    }

    public int getHeigth() {
        return heigth;
    }

    public int getWeigth() {
        return weigth;
    }
    public void Display(){
        super.Display();
        System.out.println("Laptop having length " + length + " inches, width " + width + " inches, heigth " + heigth + " inches and weigth is " + weigth +" KG's");
    }
}
// Laptop class ends
