/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.pkg8;

public class Runner_H1_lab8 {
    public static void main(String[]args){
        Date d = new Date(2,11,2001);
        Staff S = new Staff("empoyed",23000,d," M Ali ", " Lahore", " JJ3435@gmail.com", "1234567890");
        S.Display();
        Faculty F = new Faculty(8,"Chairperson",300000,d," Mr. Haider ", " Islamabad", " Hiader3435@gmail.com", "0987654321");
        F.Display();
    }
    
}
